#include "global.h"
#include "def.h"

int ginEnteroP;

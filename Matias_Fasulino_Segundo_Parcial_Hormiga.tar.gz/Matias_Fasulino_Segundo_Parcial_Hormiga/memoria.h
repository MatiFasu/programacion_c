#ifndef _MEMORIA
#define _MEMORIA

void* creo_memoria(int, int*, int);

void liberar_memoria(void* ptr_memoria, int id_memoria);

#endif

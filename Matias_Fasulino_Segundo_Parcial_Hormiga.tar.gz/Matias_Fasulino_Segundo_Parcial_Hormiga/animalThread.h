#ifndef _JUGADORTHREAD
#define _JUGADORTHREAD

void* threadAnimal(void* parametro);

#endif

#ifndef _SEMAFORO
#define _SEMAFORO

int creo_semaforo();

void inicia_semaforo(int, int);

void espera_semaforo(int);

void levanta_semaforo(int);




#endif
